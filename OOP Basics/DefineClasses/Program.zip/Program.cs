﻿
public class Program
{
    public static void Main()
    {
        var person = new Person();
        person.Name = "Pesho";
        person.Age = 20;
        var person2 = new Person() { Name = "Gosho", Age = 18 };
        var person3 = new Person() { Name = "Stamat", Age = 43 };

    }
}

